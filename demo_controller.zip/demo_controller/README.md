Weleome to the Mini Controller!


This will provide you with a containerized version of the endpoint which will reach the front-end.

As of now its represents the db fully seeded with the IBM job postings!

The end result will be two containers one for the db and one for the flask app serving the job objects.

Getting started is easy, just:

- naviagte to the root of the mini controller's directory

- run ```bash
      docker compose build
      docker compose up
      ```
This will build the containers and handle the dependancy installs, and start the containers.

once they are spun up you can check out the output by visiting: localhost:6300/api/all_jobs

