import os
from flask import Flask, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine, Column, String, Text, Enum, Integer, CHAR
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session

DATABASE_URL = os.environ["DATABASE_URL"]
app = Flask(__name__)
CORS(app)

engine = create_engine(DATABASE_URL, echo=True)
Session = scoped_session(sessionmaker(bind=engine))

Base = declarative_base()

class Job(Base):
    __tablename__ = 'jobs'

    id = Column(CHAR(36), primary_key=True)
    title = Column(String(255))
    location = Column(Text)
    description = Column(Text)
    salary = Column(String(45))
    posted_date = Column(String(45)) 
    source = Column(String(45))
    url = Column(String(255), nullable=False)
    status = Column(Enum('Open', 'Closed', 'Unknown'), nullable=False)
    internal_id = Column(String(255), nullable=False)
    company_id = Column(CHAR(36), nullable=False)
    job_category_id = Column(Integer, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'location': self.location,
            'description': self.description,
            'salary': self.salary,
            'posted_date': self.posted_date,
            'source': self.source,
            'url': self.url,
            'status': self.status,
            'internal_id': self.internal_id,
            'company_id': self.company_id,
            'job_category_id': self.job_category_id,
        }

@app.route('/api/all_jobs', methods=['GET'])
def get_jobs():
    session = Session()
    try:
        jobs = session.query(Job).all()
        job_list = [job.to_dict() for job in jobs]
        return jsonify(job_list)
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()

if __name__ == '__main__':
    print(Job.__table__.columns.keys())
    app.run(debug=True, host='0.0.0.0', port=6300)
